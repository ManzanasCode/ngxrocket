export interface iResultado {
  numeroIngresado: number;
  multiplos: number[];
  min: number;
}
